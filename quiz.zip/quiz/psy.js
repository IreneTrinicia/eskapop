
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;



const quizArray = [
  {
    id: "0",
    question: "What is PSY's birth name?",
    options: ["Park Jae-sang", "Kim Tae-hyung", "Lee Ji-eun", "Choi Seung-hyun"],
    correct: "Park Jae-sang",
  },
  {
    id: "1",
    question: "PSY's breakthrough hit 'Gangnam Style' was released in which year?",
    options: ["2010", "2011", "2012", "2013"],
    correct: "2012",
  },
  {
    id: "2",
    question: "What is the name of PSY's record label?",
    options: ["YG Entertainment", "SM Entertainment", "JYP Entertainment", "Big Hit Entertainment"],
    correct: "YG Entertainment",
  },
  {
    id: "3",
    question: "In the 'Gangnam Style' music video, which South Korean actor made a cameo appearance?",
    options: ["Lee Min-ho", "Gong Yoo", "Song Joong-ki", "Yoo Jae-suk"],
    correct: "Yoo Jae-suk",
  },
  {
    id: "4",
    question: "PSY's follow-up hit to 'Gangnam Style' is titled:",
    options: ["Daddy", "Oppa Is Just My Style", "Hangover", "Gentleman"],
    correct: "Gentleman",
  },
  {
    id: "5",
    question: "PSY collaborated with which American rapper for the song 'Hangover'?",
    options: ["Kendrick Lamar", "Snoop Dogg", "Jay-Z", "Eminem"],
    correct: "Snoop Dogg",
  },
  {
    id: "6",
    question: "Which prestigious award did PSY win for 'Gangnam Style' at the MTV Video Music Awards?",
    options: ["Best Pop Video", "Video of the Year", "Best Choreography", "Best New Artist"],
    correct: "Best Video of the Year",
  },
  {
    id: "7",
    question: "PSY served in the South Korean military as a:",
    options: ["Combat Medic", "Tank Driver", "Air Force Pilot", "Infantry Soldier"],
    correct: "Combat Medic",
  },
  {
    id: "8",
    question: "PSY's song 'Gentleman' broke the record for most YouTube views in 24 hours. What was the previous record holder?",
    options: ["Justin Bieber - 'Baby'", "BTS - 'Dynamite'", "Taylor Swift - 'Look What You Made Me Do'", "Adele - 'Hello'"],
    correct: "BTS - 'Dynamite'",
  },
  {
    id: "9",
    question: "PSY is known for his humorous and eccentric dance move in 'Gangnam Style.' What is it called?",
    options: ["Horse Dance", "Gangnam Shuffle", "Harlem Shake", "Pony Dance"],
    correct: "Horse Dance",
  }
];



restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});


nextBtn.addEventListener(
  "click",
  (displayNext = () => {
   
    questionCount += 1;
    
    if (questionCount == quizArray.length) {
     
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
     
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
     
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
  
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);


const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};


const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");

  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  
  quizCards[questionCount].classList.remove("hide");
};


function quizCreator() {

  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
   
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}


function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};