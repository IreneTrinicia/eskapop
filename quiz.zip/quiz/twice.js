//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is the name of TWICE's debut song?",
    options: ["Cheer Up", "Likey", "Like OOH-AHH", "Fancy"],
    correct: "Like OOH-AHH",
  },
  {
    id: "1",
    question: "How many members are there in TWICE?",
    options: ["Seven", "Eight", "Nine", "Ten"],
    correct: "Nine",
  },
  {
    id: "2",
    question: "Which member of TWICE is known for her 'Sha Sha Sha' line in the song 'TT'?",
    options: ["Jihyo", "Momo", "Nayeon", "Sana"],
    correct: "Sana",
  },
  {
    id: "3",
    question: "TWICE's first Japanese single is titled:",
    options: ["TT", "Cheer Up", "Likey", "One More Time"],
    correct: "One More Time",
  },
  {
    id: "4",
    question: "Which TWICE member is known for her bunny-like appearance and personality?",
    options: ["Tzuyu", "Dahyun", "Chaeyoung", "Mina"],
    correct: "Tzuyu",
  },
  {
    id: "5",
    question: "TWICE had a hit song in 2018 that starts with the lyrics 'Gyeolguk da boijiman' (In the end, we will), the English title of the song is:",
    options: ["Likey", "Fancy", "What is Love?", "Heart Shaker"],
    correct: "What is Love?",
  },
  {
    id: "6",
    question: "Which TWICE member is the group's main dancer and lead vocalist?",
    options: ["Jihyo", "Momo", "Nayeon", "Jeongyeon"],
    correct: "Momo",
  },
  {
    id: "7",
    question: "TWICE's first studio album, released in 2020, is titled:",
    options: ["More & More", "Eyes Wide Open", "Twicetagram", "Feel Special"],
    correct: "Eyes Wide Open",
  },
  {
    id: "8",
    question: "Which TWICE song has the Korean title 'TT'?",
    options: ["Knock Knock", "Signal", "Likey", "TT"],
    correct: "TT",
  },
  {
    id: "9",
    question: "TWICE won their first daesang (grand prize) at a major awards show in 2017. Which awards ceremony was it?",
    options: ["Melon Music Awards", "Mnet Asian Music Awards", "Golden Disc Awards", "Seoul Music Awards"],
    correct: "Melon Music Awards",
  }
];

//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};