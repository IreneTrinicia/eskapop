//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array
const quizArray = [
  {
    id: "0",
    question: "What is the name of EXID's debut extended play (EP)?",
    options: ["Hippity Hop", "Ah Yeah", "Street", "Up & Down"],
    correct: "Hippity Hop",
  },
  {
    id: "1",
    question: "How many members were originally in EXID's lineup when they debuted in 2012?",
    options: ["Three", "Four", "Five", "Six"],
    correct: "Six",
  },
  {
    id: "2",
    question: "Which member of EXID gained significant popularity and attention due to her fancam of the song 'Up & Down'?",
    options: ["Solji", "LE", "Hani", "Hyelin"],
    correct: "Hani",
  },
  {
    id: "3",
    question: "EXID's breakthrough hit song 'Up & Down' was released in which year?",
    options: ["2012", "2013", "2014", "2015"],
    correct: "2014",
  },
  {
    id: "4",
    question: "Which EXID song starts with the lyrics 'I feel good, nanana, nana nanana'?",
    options: ["Hot Pink", "Ah Yeah", "DDD", "L.I.E"],
    correct: "Ah Yeah",
  },
  {
    id: "5",
    question: "EXID won their first music show award for 'Up & Down' on which music program?",
    options: ["M Countdown", "Inkigayo", "Music Bank", "Show Champion"],
    correct: "Music Bank",
  },
  {
    id: "6",
    question: "Which member of EXID is the lead vocalist of the group?",
    options: ["Solji", "Hyerin", "LE", "Jeonghwa"],
    correct: "Solji",
  },
  {
    id: "7",
    question: "EXID's first full-length studio album, released in 2015, is titled:",
    options: ["Street", "Eclipse", "Full Moon", "Ah Yeah"],
    correct: "Street",
  },
  {
    id: "8",
    question: "Which EXID song has the Korean title '위아래 (Up & Down)'?",
    options: ["DDD", "Hot Pink", "L.I.E", "Up & Down"],
    correct: "Up & Down",
  },
  {
    id: "9",
    question: "EXID's official fandom name is:",
    options: ["LEGGO", "HaniSisters", "LEOnidas", "SoljiFriends"],
    correct: "LEGGO",
  }
];

//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};