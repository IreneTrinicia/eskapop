//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is the name of SEVENTEEN's debut extended play (EP)?",
    options: ["Love & Letter", "Teen, Age", "17 Carat", "You Made My Dawn"],
    correct: "17 Carat",
  },
  {
    id: "1",
    question: "How many members are there in SEVENTEEN?",
    options: ["Ten", "Thirteen", "Fifteen", "Seventeen"],
    correct: "Thirteen",
  },
  {
    id: "2",
    question: "Which member of SEVENTEEN is the leader and one of the main producers of the group?",
    options: ["Woozi", "S.Coups", "DK", "Hoshi"],
    correct: "S.Coups",
  },
  {
    id: "3",
    question: "SEVENTEEN's first studio album, released in 2016, is titled:",
    options: ["Heng:garae", "Teen, Age", "An Ode", "Love & Letter"],
    correct: "Love & Letter",
  },
  {
    id: "4",
    question: "Which SEVENTEEN song starts with the lyrics '아낀다 (Adore U)'?",
    options: ["Don't Wanna Cry", "Pretty U", "Mansae", "Home"],
    correct: "Pretty U",
  },
  {
    id: "5",
    question: "SEVENTEEN won the 'Album of the Year' award at which awards ceremony in 2020?",
    options: ["Melon Music Awards", "Golden Disc Awards", "Seoul Music Awards", "Mnet Asian Music Awards (MAMA)"],
    correct: "Mnet Asian Music Awards (MAMA)",
  },
  {
    id: "6",
    question: "Which Chinese member of SEVENTEEN is known for his powerful vocals and charming personality?",
    options: ["Joshua", "Vernon", "Jun", "The8"],
    correct: "The8",
  },
  {
    id: "7",
    question: "SEVENTEEN's sub-unit, which focuses on Hip-hop and Urban style music, is named:",
    options: ["Vocal Team", "Performance Team", "Hip-Hop Team", "B-Team"],
    correct: "Hip-Hop Team",
  },
  {
    id: "8",
    question: "Which SEVENTEEN song has the Korean title '독: Fear', which translates to 'Fear' in English?",
    options: ["Clap", "Getting Closer", "Hit", "Fear"],
    correct: "Fear",
  },
  {
    id: "9",
    question: "SEVENTEEN's official fandom name is:",
    options: ["Carats", "Diamonds", "Emeralds", "Gems"],
    correct: "Carats",
  }
];



//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};