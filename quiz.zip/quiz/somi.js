//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is Somi's full name?",
    options: ["Ennik Somi Douma", "Kim Tae-hyung", "Park Jae-sang", "Choi Seung-hyun"],
    correct: "Ennik Somi Douma",
  },
  {
    id: "1",
    question: "Somi gained initial fame as a contestant on which South Korean survival show?",
    options: ["Produce 101", "Unpretty Rapstar", "Show Me the Money", "Kingdom: Legendary War"],
    correct: "Produce 101",
  },
  {
    id: "2",
    question: "Which entertainment agency represents Somi?",
    options: ["YG Entertainment", "SM Entertainment", "JYP Entertainment", "The Black Label"],
    correct: "The Black Label",
  },
  {
    id: "3",
    question: "Somi made her solo debut with the song 'Birthday' in which year?",
    options: ["2016", "2017", "2018", "2019"],
    correct: "2019",
  },
  {
    id: "4",
    question: "Before her solo debut, Somi was a member of which popular K-pop girl group?",
    options: ["BLACKPINK", "Red Velvet", "TWICE", "IOI"],
    correct: "IOI",
  },
  {
    id: "5",
    question: "Somi's mother is Korean, and her father is from which country?",
    options: ["Canada", "China", "Thailand", "The Netherlands"],
    correct: "The Netherlands",
  },
  {
    id: "6",
    question: "Which song by Somi became a hit and won on music shows after her solo debut?",
    options: ["What You Waiting For", "Dumb Dumb", "Ice Cream Cake", "Forever Young"],
    correct: "What You Waiting For",
  },
  {
    id: "7",
    question: "Somi was born on March 9, 2001, making her zodiac sign:",
    options: ["Aries", "Leo", "Pisces", "Aquarius"],
    correct: "Pisces",
  },
  {
    id: "8",
    question: "Which variety show did Somi join as a fixed cast member?",
    options: ["Running Man", "Knowing Bros", "New Journey to the West", "I Live Alone"],
    correct: "Running Man",
  },
  {
    id: "9",
    question: "Somi's pre-debut song 'BIRTHDAY' was released under which label?",
    options: ["The Black Label", "YG Entertainment", "JYP Entertainment", "Stone Music Entertainment"],
    correct: "The Black Label",
  }
];

//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};