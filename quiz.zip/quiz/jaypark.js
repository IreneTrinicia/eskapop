//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is Jay Park's Korean name?",
    options: ["Park Jae-sang", "Kim Tae-hyung", "Choi Seung-hyun", "Park Jae-beom"],
    correct: "Park Jae-beom",
  },
  {
    id: "1",
    question: "Jay Park was a former member of which K-pop boy group?",
    options: ["BTS", "EXO", "GOT7", "2PM"],
    correct: "2PM",
  },
  {
    id: "2",
    question: "Which South Korean entertainment agency is the founder of Jay Park's own label?",
    options: ["JYP Entertainment", "YG Entertainment", "AOMG", "SM Entertainment"],
    correct: "AOMG",
  },
  {
    id: "3",
    question: "What is the title of Jay Park's debut solo album?",
    options: ["New Breed", "Evolution", "Worldwide", "Everything You Wanted"],
    correct: "New Breed",
  },
  {
    id: "4",
    question: "Jay Park was born and raised in which city in the United States?",
    options: ["Los Angeles", "New York", "Chicago", "Houston"],
    correct: "Seattle",
  },
  {
    id: "5",
    question: "Which song by Jay Park features the American rapper 2 Chainz?",
    options: ["Mommae", "Drive", "Yacht", "All I Wanna Do"],
    correct: "Soju",
  },
  {
    id: "6",
    question: "Jay Park gained international recognition and won the 'Best International Artist' award at which ceremony?",
    options: ["MTV Video Music Awards", "BET Awards", "Grammy Awards", "Mnet Asian Music Awards"],
    correct: "Mnet Asian Music Awards",
  },
  {
    id: "7",
    question: "Which popular South Korean variety show did Jay Park join as a fixed cast member?",
    options: ["Running Man", "Knowing Bros", "Infinity Challenge", "Return of Superman"],
    correct: "Knowing Bros",
  },
  {
    id: "8",
    question: "Jay Park collaborated with which American hip-hop artist for the song 'All I Wanna Do'?",
    options: ["Jay-Z", "Snoop Dogg", "Kendrick Lamar", "Chris Brown"],
    correct: "Hoodie Allen",
  },
  {
    id: "9",
    question: "Jay Park's label AOMG stands for 'Above Ordinary Music Group'.",
    options: ["True", "False"],
    correct: "True",
  }
];

//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};