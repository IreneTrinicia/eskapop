//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is the name of ATEEZ's debut extended play (EP)?",
    options: ["TREASURE EP.1: All to Zero", "TREASURE EP.2: Zero to One", "TREASURE EP.3: One to All", "TREASURE EP.4: The End"],
    correct: "TREASURE EP.1: All to Zero",
  },
  {
    id: "1",
    question: "How many members are there in ATEEZ?",
    options: ["Seven", "Eight", "Nine", "Ten"],
    correct: "Eight",
  },
  {
    id: "2",
    question: "Which member of ATEEZ is known for his deep, powerful rap verses and his stage name 'Mingi'?",
    options: ["Yunho", "Seonghwa", "Mingi", "Wooyoung"],
    correct: "Mingi",
  },
  {
    id: "3",
    question: "ATEEZ's first full-length studio album, released in 2020, is titled:",
    options: ["TREASURE EP.FIN: All to Action", "ZERO: FEVER Part.1", "TREASURE EP. EXTRA: Shift the Map", "FEVER Part.2"],
    correct: "ZERO: FEVER Part.1",
  },
  {
    id: "4",
    question: "Which ATEEZ song starts with the lyrics 'Yo listen up, this is my confession'?",
    options: ["Say My Name", "Hala Hala", "Wave", "Answer"],
    correct: "Say My Name",
  },
  {
    id: "5",
    question: "ATEEZ won the 'Worldwide Fans' Choice Top 10' award at which awards ceremony in 2020?",
    options: ["Melon Music Awards", "Golden Disc Awards", "Mnet Asian Music Awards (MAMA)", "Seoul Music Awards"],
    correct: "Mnet Asian Music Awards (MAMA)",
  },
  {
    id: "6",
    question: "Which member of ATEEZ is the main dancer and lead vocalist of the group?",
    options: ["San", "Hongjoong", "Yeosang", "Jongho"],
    correct: "San",
  },
  {
    id: "7",
    question: "ATEEZ's fourth EP, released in 2021, is titled:",
    options: ["TREASURE EP.FIN: All to Action", "ZERO: FEVER Part.1", "TREASURE EP. Map to Answer", "ZERO: FEVER Part.2"],
    correct: "ZERO: FEVER Part.2",
  },
  {
    id: "8",
    question: "Which ATEEZ song has the Korean title '우린 (Oasis)'?",
    options: ["Wave", "Answer", "Say My Name", "Oasis"],
    correct: "Answer",
  },
  {
    id: "9",
    question: "ATEEZ's official fandom name is:",
    options: ["ATEEN", "ATINY", "ATEEZERS", "ATOMIC"],
    correct: "ATINY",
  }
];



//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};