//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
  {
    id: "0",
    question: "What is the name of ENHYPEN's debut extended play (EP)?",
    options: ["BORDER: DAY ONE", "BORDER: CARNIVAL", "BORDER: Hakanai", "BORDER: Minus"],
    correct: "BORDER: DAY ONE",
  },
  {
    id: "1",
    question: "How many members are there in ENHYPEN?",
    options: ["Six", "Seven", "Eight", "Nine"],
    correct: "Seven",
  },
  {
    id: "2",
    question: "Which member of ENHYPEN was the center and won the final episode of 'I-LAND,' a survival reality show from which the group was formed?",
    options: ["Sunghoon", "Jungwon", "Heeseung", "Jake"],
    correct: "Jungwon",
  },
  {
    id: "3",
    question: "ENHYPEN's debut extended play (EP) was released in which year?",
    options: ["2020", "2021", "2022", "2023"],
    correct: "2020",
  },
  {
    id: "4",
    question: "Which ENHYPEN song starts with the lyrics 'I give you my heart'?",
    options: ["Flicker", "Drunk-Dazed", "Given-Taken", "Let Me In (20 CUBE)"],
    correct: "Given-Taken",
  },
  {
    id: "5",
    question: "ENHYPEN won the 'Best New Male Artist' award at which awards ceremony in 2021?",
    options: ["Melon Music Awards", "Golden Disc Awards", "Seoul Music Awards", "Mnet Asian Music Awards (MAMA)"],
    correct: "Mnet Asian Music Awards (MAMA)",
  },
  {
    id: "6",
    question: "Which member of ENHYPEN is the lead dancer and sub-vocalist of the group?",
    options: ["Heeseung", "Sunghoon", "Jungwon", "Sunoo"],
    correct: "Sunghoon",
  },
  {
    id: "7",
    question: "ENHYPEN's second EP, released in 2021, is titled:",
    options: ["BORDER: DAY TWO", "BORDER: CARNIVAL", "BORDER: Hakanai", "BORDER: Minus"],
    correct: "BORDER: CARNIVAL",
  },
  {
    id: "8",
    question: "Which ENHYPEN song has the Korean title 'Drunk-Dazed'?",
    options: ["Flicker", "Drunk-Dazed", "Given-Taken", "Let Me In (20 CUBE)"],
    correct: "Drunk-Dazed",
  },
  {
    id: "9",
    question: "ENHYPEN's official fandom name is:",
    options: ["ENGENE", "ENHYPENIES", "ENHANCERS", "ENHYPENIS"],
    correct: "ENGENE",
  }
];


//Restart Quiz
restart.addEventListener("click", () => {
  initial();
  displayContainer.classList.remove("hide");
  scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
  "click",
  (displayNext = () => {
    //increment questionCount
    questionCount += 1;
    //if last question
    if (questionCount == quizArray.length) {
      //hide question container and display score
      displayContainer.classList.add("hide");
      scoreContainer.classList.remove("hide");
      //user score
      userScore.innerHTML =
        "Your score is " + scoreCount + " out of " + questionCount;
    } else {
      //display questionCount
      countOfQuestion.innerHTML =
        questionCount + 1 + " of " + quizArray.length + " Question";
      //display quiz
      quizDisplay(questionCount);
      count = 11;
      clearInterval(countdown);
      timerDisplay();
    }
  })
);

//Timer
const timerDisplay = () => {
  countdown = setInterval(() => {
    count--;
    timeLeft.innerHTML = `${count}s`;
    if (count == 0) {
      clearInterval(countdown);
      displayNext();
    }
  }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
  let quizCards = document.querySelectorAll(".container-mid");
  //Hide other cards
  quizCards.forEach((card) => {
    card.classList.add("hide");
  });
  //display current question card
  quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
  //randomly sort questions
  quizArray.sort(() => Math.random() - 0.5);
  //generate quiz
  for (let i of quizArray) {
    //randomly sort options
    i.options.sort(() => Math.random() - 0.5);
    //quiz card creation
    let div = document.createElement("div");
    div.classList.add("container-mid", "hide");
    //question number
    countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
    //question
    let question_DIV = document.createElement("p");
    question_DIV.classList.add("question");
    question_DIV.innerHTML = i.question;
    div.appendChild(question_DIV);
    //options
    div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
    quizContainer.appendChild(div);
  }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
  let userSolution = userOption.innerText;
  let question =
    document.getElementsByClassName("container-mid")[questionCount];
  let options = question.querySelectorAll(".option-div");

  //if user clicked answer == correct option stored in object
  if (userSolution === quizArray[questionCount].correct) {
    userOption.classList.add("correct");
    scoreCount++;
  } else {
    userOption.classList.add("incorrect");
    //For marking the correct option
    options.forEach((element) => {
      if (element.innerText == quizArray[questionCount].correct) {
        element.classList.add("correct");
      }
    });
  }

  //clear interval(stop timer)
  clearInterval(countdown);
  //disable all options
  options.forEach((element) => {
    element.disabled = true;
  });
}

//initial setup
function initial() {
  quizContainer.innerHTML = "";
  questionCount = 0;
  scoreCount = 0;
  count = 11;
  clearInterval(countdown);
  timerDisplay();
  quizCreator();
  quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
  startScreen.classList.add("hide");
  displayContainer.classList.remove("hide");
  initial();
});

//hide quiz and display start screen
window.onload = () => {
  startScreen.classList.remove("hide");
  displayContainer.classList.add("hide");
};